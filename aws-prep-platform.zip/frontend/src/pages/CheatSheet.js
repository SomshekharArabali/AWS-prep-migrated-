"use client"

import { useState } from "react"
import "./CheatSheet.css"

const CheatSheet = () => {
  const [activeSection, setActiveSection] = useState("services")

  const cheatSheetData = {
    services: {
      title: "AWS Core Services",
      content: [
        {
          category: "Compute",
          items: [
            { name: "EC2", description: "Virtual servers in the cloud" },
            { name: "Lambda", description: "Serverless compute service" },
            { name: "ECS", description: "Container orchestration service" },
            { name: "Fargate", description: "Serverless containers" },
          ],
        },
        {
          category: "Storage",
          items: [
            { name: "S3", description: "Object storage service" },
            { name: "EBS", description: "Block storage for EC2" },
            { name: "EFS", description: "Managed file system" },
            { name: "Glacier", description: "Long-term archival storage" },
          ],
        },
        {
          category: "Database",
          items: [
            { name: "RDS", description: "Managed relational database" },
            { name: "DynamoDB", description: "NoSQL database service" },
            { name: "ElastiCache", description: "In-memory caching" },
            { name: "Redshift", description: "Data warehouse service" },
          ],
        },
      ],
    },
    pricing: {
      title: "AWS Pricing Models",
      content: [
        {
          category: "Pricing Models",
          items: [
            { name: "On-Demand", description: "Pay for what you use with no upfront costs" },
            { name: "Reserved Instances", description: "1-3 year commitments for discounted rates" },
            { name: "Spot Instances", description: "Bid for unused EC2 capacity" },
            { name: "Dedicated Hosts", description: "Physical servers dedicated to your use" },
          ],
        },
        {
          category: "Cost Management",
          items: [
            { name: "AWS Cost Explorer", description: "Visualize and manage AWS costs" },
            { name: "AWS Budgets", description: "Set custom cost and usage budgets" },
            { name: "AWS Cost and Usage Report", description: "Detailed billing reports" },
            { name: "AWS Trusted Advisor", description: "Cost optimization recommendations" },
          ],
        },
      ],
    },
    security: {
      title: "Security & Compliance",
      content: [
        {
          category: "Identity & Access",
          items: [
            { name: "IAM", description: "Identity and Access Management" },
            { name: "AWS SSO", description: "Single Sign-On service" },
            { name: "Cognito", description: "User identity and authentication" },
            { name: "Directory Service", description: "Managed Microsoft Active Directory" },
          ],
        },
        {
          category: "Security Services",
          items: [
            { name: "CloudTrail", description: "API logging and monitoring" },
            { name: "Config", description: "Resource configuration monitoring" },
            { name: "GuardDuty", description: "Threat detection service" },
            { name: "Inspector", description: "Security assessment service" },
          ],
        },
      ],
    },
    architecture: {
      title: "Architecture Principles",
      content: [
        {
          category: "Well-Architected Framework",
          items: [
            { name: "Operational Excellence", description: "Run and monitor systems effectively" },
            { name: "Security", description: "Protect information and systems" },
            { name: "Reliability", description: "Recover from failures and meet demand" },
            { name: "Performance Efficiency", description: "Use resources efficiently" },
            { name: "Cost Optimization", description: "Avoid unnecessary costs" },
          ],
        },
        {
          category: "Design Principles",
          items: [
            { name: "Scalability", description: "Handle increased load gracefully" },
            { name: "Elasticity", description: "Scale resources up and down automatically" },
            { name: "High Availability", description: "Minimize downtime and failures" },
            { name: "Fault Tolerance", description: "Continue operating despite failures" },
          ],
        },
      ],
    },
  }

  const sections = [
    { key: "services", label: "Core Services", icon: "🔧" },
    { key: "pricing", label: "Pricing", icon: "💰" },
    { key: "security", label: "Security", icon: "🔒" },
    { key: "architecture", label: "Architecture", icon: "🏗️" },
  ]

  return (
    <div className="cheat-sheet">
      <div className="container">
        <div className="cheat-sheet-header">
          <h1>AWS Cloud Practitioner Cheat Sheet</h1>
          <p>Quick reference guide for key AWS concepts and services</p>
        </div>

        <div className="cheat-sheet-content">
          <div className="cheat-sheet-nav">
            {sections.map((section) => (
              <button
                key={section.key}
                onClick={() => setActiveSection(section.key)}
                className={`nav-btn ${activeSection === section.key ? "active" : ""}`}
              >
                <span className="nav-icon">{section.icon}</span>
                <span className="nav-label">{section.label}</span>
              </button>
            ))}
          </div>

          <div className="cheat-sheet-main">
            <h2>{cheatSheetData[activeSection].title}</h2>

            <div className="content-sections">
              {cheatSheetData[activeSection].content.map((section, index) => (
                <div key={index} className="content-section">
                  <h3>{section.category}</h3>
                  <div className="items-grid">
                    {section.items.map((item, itemIndex) => (
                      <div key={itemIndex} className="cheat-item">
                        <h4>{item.name}</h4>
                        <p>{item.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default CheatSheet
