"use client"

import { useState, useEffect } from "react"
import { apiClient } from "../utils/api"
import { useAuth } from "../contexts/AuthContext"
import LoadingSpinner from "../components/LoadingSpinner"
import "./Modules.css"

const Modules = () => {
  const [modules, setModules] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedModule, setSelectedModule] = useState(null)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [userAnswers, setUserAnswers] = useState({})
  const [showResults, setShowResults] = useState(false)
  const [moduleQuestions, setModuleQuestions] = useState([])
  const { updateProgress } = useAuth()

  useEffect(() => {
    fetchModules()
  }, [])

  const fetchModules = async () => {
    try {
      const response = await apiClient.modules.getAll()
      setModules(response.data)
    } catch (error) {
      console.error("Error fetching modules:", error)
      // Fallback to placeholder data if API fails
      setModules([
        { id: 1, title: "Module 1: Cloud Concepts Overview", questions: 15, completed: false },
        { id: 2, title: "Module 2: AWS Core Services", questions: 20, completed: false },
        { id: 3, title: "Module 3: Security and Compliance", questions: 18, completed: false },
        { id: 4, title: "Module 4: Pricing and Support", questions: 12, completed: false },
        { id: 5, title: "Module 5: Architecture and Design", questions: 16, completed: false },
        { id: 6, title: "Module 6: Deployment and Operations", questions: 14, completed: false },
        { id: 7, title: "Module 7: Networking and Content Delivery", questions: 17, completed: false },
        { id: 8, title: "Module 8: Storage and Databases", questions: 19, completed: false },
        { id: 9, title: "Module 9: Analytics and Machine Learning", questions: 13, completed: false },
        { id: 10, title: "Module 10: Management and Governance", questions: 15, completed: false },
      ])
    } finally {
      setLoading(false)
    }
  }

  const startModule = async (module) => {
    try {
      setLoading(true)
      const response = await apiClient.modules.getById(module.id)
      setModuleQuestions(response.data.questions || [])
      setSelectedModule(module)
      setCurrentQuestion(0)
      setUserAnswers({})
      setShowResults(false)
    } catch (error) {
      console.error("Error loading module questions:", error)
      // Use sample questions if API fails
      setModuleQuestions([
        {
          question_id: 1,
          question_text: "Sample question - your JSON data will replace this",
          options: [
            { option_id: 1, option_text: "Option A" },
            { option_id: 2, option_text: "Option B" },
            { option_id: 3, option_text: "Option C" },
            { option_id: 4, option_text: "Option D" },
          ],
          correct_answer_id: 1,
        },
      ])
      setSelectedModule(module)
      setCurrentQuestion(0)
      setUserAnswers({})
      setShowResults(false)
    } finally {
      setLoading(false)
    }
  }

  const handleAnswer = (questionId, answerId) => {
    setUserAnswers((prev) => ({
      ...prev,
      [questionId]: answerId,
    }))
  }

  const nextQuestion = async () => {
    if (currentQuestion < moduleQuestions.length - 1) {
      setCurrentQuestion((prev) => prev + 1)
    } else {
      const correctAnswers = moduleQuestions.filter((q) => userAnswers[q.question_id] === q.correct_answer_id).length
      const score = Math.round((correctAnswers / moduleQuestions.length) * 100)

      try {
        await updateProgress({
          moduleId: selectedModule.id,
          score,
          timeSpent: 45, // You could track actual time
        })
      } catch (error) {
        console.error("Error updating progress:", error)
      }

      setShowResults(true)
    }
  }

  const backToModules = () => {
    setSelectedModule(null)
    setShowResults(false)
  }

  if (loading) {
    return <LoadingSpinner message="Loading modules..." />
  }

  if (selectedModule) {
    return (
      <div className="module-quiz">
        <div className="container">
          <div className="quiz-header">
            <button onClick={backToModules} className="back-btn">
              ← Back to Modules
            </button>
            <h1>{selectedModule.title}</h1>
            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{ width: `${((currentQuestion + 1) / moduleQuestions.length) * 100}%` }}
              ></div>
            </div>
            <p>
              Question {currentQuestion + 1} of {moduleQuestions.length}
            </p>
          </div>

          {!showResults ? (
            <div className="question-card">
              <h3>{moduleQuestions[currentQuestion].question_text}</h3>
              <p>
                This is where your JSON question data will be displayed. The question text, options, and correct answers
                will be loaded from your JSON files.
              </p>

              <div className="question-options">
                {moduleQuestions[currentQuestion].options.map((option) => (
                  <div key={option.option_id} className="option">
                    <input
                      type="radio"
                      id={`option${option.option_id}`}
                      name="answer"
                      checked={userAnswers[moduleQuestions[currentQuestion].question_id] === option.option_id}
                      onChange={() => handleAnswer(moduleQuestions[currentQuestion].question_id, option.option_id)}
                    />
                    <label htmlFor={`option${option.option_id}`}>{option.option_text}</label>
                  </div>
                ))}
              </div>

              <button onClick={nextQuestion} className="btn btn-primary next-btn">
                {currentQuestion < moduleQuestions.length - 1 ? "Next Question" : "Finish Module"}
              </button>
            </div>
          ) : (
            <div className="results-card">
              <h2>Module Complete!</h2>
              <p>You have completed {selectedModule.title}</p>
              <div className="results-stats">
                <div className="stat">
                  <span className="stat-number">85%</span>
                  <span className="stat-label">Score</span>
                </div>
                <div className="stat">
                  <span className="stat-number">{moduleQuestions.length}</span>
                  <span className="stat-label">Questions</span>
                </div>
              </div>
              <button onClick={backToModules} className="btn btn-primary">
                Back to Modules
              </button>
            </div>
          )}
        </div>
      </div>
    )
  }

  return (
    <div className="modules">
      <div className="container">
        <div className="modules-header">
          <h1>Learning Modules</h1>
          <p>10 comprehensive modules covering all AWS Cloud Practitioner exam domains</p>
        </div>

        <div className="modules-grid">
          {modules.map((module) => (
            <div key={module.id} className="module-card">
              <div className="module-header">
                <h3>{module.title}</h3>
                <span className="question-count">{module.questions} questions</span>
              </div>

              <div className="module-progress">
                <div className="progress-bar">
                  <div className="progress-fill" style={{ width: module.completed ? "100%" : "0%" }}></div>
                </div>
                <span className="progress-text">{module.completed ? "Completed" : "Not Started"}</span>
              </div>

              <button onClick={() => startModule(module)} className="btn btn-primary module-btn">
                {module.completed ? "Review" : "Start Module"}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default Modules
