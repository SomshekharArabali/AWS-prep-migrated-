const express = require("express")
const { requireAuth } = require("../middleware/auth")
const router = express.Router()

// Get user progress overview
router.get("/", requireAuth, async (req, res) => {
  try {
    const userId = req.auth.userId

    // In a real app, you'd fetch this from your database
    const progressData = {
      userId,
      overall: {
        modulesCompleted: 3,
        totalModules: 10,
        questionSetsCompleted: 5,
        totalQuestionSets: 11,
        questionsAnswered: 245,
        averageScore: 78,
        timeSpent: 1250, // minutes
      },
      modules: [
        { id: 1, completed: true, score: 85, timeSpent: 45 },
        { id: 2, completed: true, score: 72, timeSpent: 60 },
        { id: 3, completed: true, score: 88, timeSpent: 55 },
        { id: 4, completed: false, score: null, timeSpent: 0 },
      ],
      questionSets: [
        { id: 1, completed: true, score: 82, attempts: 2, bestScore: 82 },
        { id: 2, completed: true, score: 75, attempts: 1, bestScore: 75 },
        { id: 3, completed: false, score: null, attempts: 0, bestScore: null },
      ],
      recentActivity: [
        {
          type: "module",
          id: 3,
          title: "Module 3: Security and Compliance",
          score: 88,
          completedAt: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
        },
        {
          type: "questionSet",
          id: 2,
          title: "Practice Set 2: AWS Core Services",
          score: 75,
          completedAt: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
        },
      ],
    }

    res.json(progressData)
  } catch (error) {
    console.error("Error fetching progress:", error)
    res.status(500).json({ error: "Failed to fetch progress data" })
  }
})

// Get progress for specific module
router.get("/module/:id", requireAuth, async (req, res) => {
  try {
    const moduleId = Number.parseInt(req.params.id)
    const userId = req.auth.userId

    // Mock module progress data
    const moduleProgress = {
      moduleId,
      userId,
      completed: false,
      score: null,
      timeSpent: 0,
      questionsAnswered: 0,
      totalQuestions: 15,
      attempts: 0,
      lastAttempt: null,
    }

    res.json(moduleProgress)
  } catch (error) {
    console.error("Error fetching module progress:", error)
    res.status(500).json({ error: "Failed to fetch module progress" })
  }
})

// Get progress for specific question set
router.get("/questions/:id", requireAuth, async (req, res) => {
  try {
    const questionSetId = Number.parseInt(req.params.id)
    const userId = req.auth.userId

    // Mock question set progress data
    const questionSetProgress = {
      questionSetId,
      userId,
      completed: false,
      bestScore: null,
      attempts: 0,
      averageScore: null,
      totalTimeSpent: 0,
      lastAttempt: null,
    }

    res.json(questionSetProgress)
  } catch (error) {
    console.error("Error fetching question set progress:", error)
    res.status(500).json({ error: "Failed to fetch question set progress" })
  }
})

module.exports = router
