const express = require("express")
const fs = require("fs").promises
const path = require("path")
const { requireAuth } = require("../middleware/auth")
const router = express.Router()

// Get all modules
router.get("/", requireAuth, async (req, res) => {
  try {
    // In a real app, you'd fetch from database
    // For now, return static module data
    const modules = [
      {
        id: 1,
        title: "Module 1: Cloud Concepts Overview",
        description: "Introduction to cloud computing concepts and AWS fundamentals",
        questions: 15,
        completed: false,
        difficulty: "Beginner",
        estimatedTime: "45 minutes",
      },
      {
        id: 2,
        title: "Module 2: AWS Core Services",
        description: "Essential AWS services including EC2, S3, and VPC",
        questions: 20,
        completed: false,
        difficulty: "Intermediate",
        estimatedTime: "60 minutes",
      },
      {
        id: 3,
        title: "Module 3: Security and Compliance",
        description: "AWS security best practices and compliance frameworks",
        questions: 18,
        completed: false,
        difficulty: "Intermediate",
        estimatedTime: "55 minutes",
      },
      {
        id: 4,
        title: "Module 4: Pricing and Support",
        description: "AWS pricing models and support plans",
        questions: 12,
        completed: false,
        difficulty: "Beginner",
        estimatedTime: "35 minutes",
      },
      {
        id: 5,
        title: "Module 5: Architecture and Design",
        description: "Well-architected framework and design principles",
        questions: 16,
        completed: false,
        difficulty: "Advanced",
        estimatedTime: "50 minutes",
      },
    ]

    res.json(modules)
  } catch (error) {
    console.error("Error fetching modules:", error)
    res.status(500).json({ error: "Failed to fetch modules" })
  }
})

// Get specific module with questions
router.get("/:id", requireAuth, async (req, res) => {
  try {
    const moduleId = Number.parseInt(req.params.id)

    // Try to load questions from JSON file
    try {
      const jsonPath = path.join(__dirname, "../data/modules", `module-${moduleId}.json`)
      const jsonData = await fs.readFile(jsonPath, "utf8")
      const moduleData = JSON.parse(jsonData)

      res.json(moduleData)
    } catch (fileError) {
      // If JSON file doesn't exist, return sample data
      console.log(`Module ${moduleId} JSON file not found, returning sample data`)

      const sampleModule = {
        id: moduleId,
        title: `Module ${moduleId}: Sample Module`,
        questions: [
          {
            question_id: 1,
            question_text: "This is a sample question. Your JSON data will replace this.",
            options: [
              { option_id: 1, option_text: "Sample option A" },
              { option_id: 2, option_text: "Sample option B" },
              { option_id: 3, option_text: "Sample option C" },
              { option_id: 4, option_text: "Sample option D" },
            ],
            correct_answer_id: 1,
            explanation: "This is where the explanation for the correct answer would appear.",
          },
        ],
      }

      res.json(sampleModule)
    }
  } catch (error) {
    console.error("Error fetching module:", error)
    res.status(500).json({ error: "Failed to fetch module data" })
  }
})

module.exports = router
