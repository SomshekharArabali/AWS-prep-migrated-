const express = require("express")
const fs = require("fs").promises
const path = require("path")
const { requireAuth } = require("../middleware/auth")
const router = express.Router()

// Get all question sets
router.get("/", requireAuth, async (req, res) => {
  try {
    const questionSets = [
      {
        id: 1,
        title: "Practice Set 1: Cloud Concepts",
        description: "Fundamental cloud computing concepts and terminology",
        questions: 65,
        difficulty: "Beginner",
        completed: false,
        averageScore: null,
        timeLimit: 90, // minutes
      },
      {
        id: 2,
        title: "Practice Set 2: AWS Core Services",
        description: "Essential AWS services and their use cases",
        questions: 85,
        difficulty: "Intermediate",
        completed: false,
        averageScore: null,
        timeLimit: 120,
      },
      {
        id: 3,
        title: "Practice Set 3: Security & Compliance",
        description: "AWS security services and compliance requirements",
        questions: 75,
        difficulty: "Intermediate",
        completed: false,
        averageScore: null,
        timeLimit: 110,
      },
      {
        id: 11,
        title: "Full Practice Exam",
        description: "Complete CLF-C02 practice exam simulation",
        questions: 65,
        difficulty: "Exam",
        completed: false,
        averageScore: null,
        timeLimit: 90,
      },
    ]

    res.json(questionSets)
  } catch (error) {
    console.error("Error fetching question sets:", error)
    res.status(500).json({ error: "Failed to fetch question sets" })
  }
})

// Get specific question set
router.get("/:id", requireAuth, async (req, res) => {
  try {
    const setId = Number.parseInt(req.params.id)

    // Try to load questions from JSON file
    try {
      const jsonPath = path.join(__dirname, "../data/questions", `question-set-${setId}.json`)
      const jsonData = await fs.readFile(jsonPath, "utf8")
      const questionSetData = JSON.parse(jsonData)

      res.json(questionSetData)
    } catch (fileError) {
      // If JSON file doesn't exist, return sample data
      console.log(`Question set ${setId} JSON file not found, returning sample data`)

      const sampleQuestionSet = {
        id: setId,
        title: `Practice Set ${setId}: Sample Questions`,
        questions: [
          {
            question_id: 1,
            question_text: "AWS Cloud Adoption Framework (CAF) is organized into how many perspectives?",
            options: [
              { option_id: 1, option_text: "ten" },
              { option_id: 2, option_text: "eight" },
              { option_id: 3, option_text: "four" },
              { option_id: 4, option_text: "six" },
            ],
            correct_answer_id: 4,
            explanation:
              "The AWS CAF is organized into six perspectives: Business, People, Governance, Platform, Security, and Operations.",
          },
          {
            question_id: 2,
            question_text:
              "If an organisation needs to host their IT system on dedicated resources due to compliance reasons. Which cloud computing deployment model should be used?",
            options: [
              { option_id: 1, option_text: "Cloud" },
              { option_id: 2, option_text: "On-premises" },
              { option_id: 3, option_text: "Legacy cloud" },
              { option_id: 4, option_text: "Hybrid" },
            ],
            correct_answer_id: 2,
            explanation:
              "On-premises deployment provides dedicated resources and full control, which is often required for strict compliance requirements.",
          },
        ],
      }

      res.json(sampleQuestionSet)
    }
  } catch (error) {
    console.error("Error fetching question set:", error)
    res.status(500).json({ error: "Failed to fetch question set data" })
  }
})

// Submit quiz answers
router.post("/:id/submit", requireAuth, async (req, res) => {
  try {
    const setId = Number.parseInt(req.params.id)
    const { answers, timeSpent } = req.body
    const userId = req.auth.userId

    // In a real app, you'd:
    // 1. Load the correct answers from your data
    // 2. Calculate the score
    // 3. Save the results to database
    // 4. Update user progress

    // For now, return mock results
    const totalQuestions = Object.keys(answers).length
    const correctAnswers = Math.floor(totalQuestions * 0.75) // Mock 75% score
    const score = Math.round((correctAnswers / totalQuestions) * 100)

    const results = {
      questionSetId: setId,
      userId,
      totalQuestions,
      correctAnswers,
      score,
      timeSpent,
      submittedAt: new Date().toISOString(),
    }

    console.log("Quiz submitted:", results)

    res.json({
      success: true,
      results,
    })
  } catch (error) {
    console.error("Error submitting quiz:", error)
    res.status(500).json({ error: "Failed to submit quiz" })
  }
})

module.exports = router
