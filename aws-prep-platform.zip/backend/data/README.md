# Data Directory

This directory should contain your JSON files with quiz questions and modules.

## Expected File Structure:

\`\`\`
data/
├── modules/
│   ├── module-1.json
│   ├── module-2.json
│   ├── module-3.json
│   └── ...
└── questions/
    ├── question-set-1.json
    ├── question-set-2.json
    ├── question-set-3.json
    └── ...
\`\`\`

## JSON File Format:

### Module Files (module-X.json):
\`\`\`json
{
  "id": 1,
  "title": "Module 1: Cloud Concepts Overview",
  "questions": [
    {
      "question_id": 1,
      "question_text": "Your question here",
      "options": [
        {"option_id": 1, "option_text": "Option A"},
        {"option_id": 2, "option_text": "Option B"},
        {"option_id": 3, "option_text": "Option C"},
        {"option_id": 4, "option_text": "Option D"}
      ],
      "correct_answer_id": 1,
      "explanation": "Explanation for the correct answer"
    }
  ]
}
\`\`\`

### Question Set Files (question-set-X.json):
Same format as module files, but typically contain more questions.

## Instructions:
1. Create the `modules/` and `questions/` subdirectories
2. Add your JSON files following the naming convention above
3. The API will automatically load these files when requested
4. If files don't exist, the API returns sample data
