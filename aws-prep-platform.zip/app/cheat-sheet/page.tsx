export default function CheatSheetPage() {
  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-foreground mb-4">Cheat Sheet</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Quick reference guide for AWS Cloud Practitioner exam concepts.
          </p>
        </div>
        <div className="bg-card rounded-lg p-8 text-center">
          <p className="text-muted-foreground">Cheat sheet content coming soon...</p>
        </div>
      </div>
    </main>
  )
}
