import { AboutContent } from "@/components/about-content"

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-background">
      <AboutContent />
    </main>
  )
}
